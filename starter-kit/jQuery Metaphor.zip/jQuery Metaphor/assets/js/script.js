$('document').ready(function(){





	$('.upper').mouseenter(function() {
		$('.lower').fadeOut(1000);
	});

	$('.upper').mouseenter(function() {
		$('.upper').fadeOut(1000);
	});

	$('.lower').mouseenter(function() {
	$('.lower').fadeIn(10);
	});

	$('.lower').mouseenter(function() {
	$('.upper').fadeIn(10);
	});


















});